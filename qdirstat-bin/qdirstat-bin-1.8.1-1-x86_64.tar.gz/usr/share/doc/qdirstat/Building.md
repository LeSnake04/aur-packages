# Building QDirStat

See [main document](https://github.com/shundhammer/qdirstat/blob/master/README.md#building)
